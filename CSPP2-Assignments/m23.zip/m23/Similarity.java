import java.util.*;
class Similarity {
	private Document[] documents;
	private int documentArraySize;

	Similarity() {
		documents = new Document[10];
		documentArraySize = 0;
	}

	public Document[] getDocument() {
		return documents;
	}

	public void addDocument(Document d) {
		documents[documentArraySize++] = d;
	}

	public Document findDocument(String name) {
		// for(Document d : documents) {
		// 	if(d.getfilename().equals(name)) {
		// 		return d;
		// 	}
		// }
		for(int i = 0; i < documentArraySize; i++) {
			if(documents[i].getfilename().equals(name)) {
				return documents[i];
			}
		}
		return null;
	}

	public double getEuclideanNorm(String filename) {
		Document d = findDocument(filename);
		HashMap<String, Integer> hashmap = d.getHashMap();
		Double value = 0.0;
		int currentValue = 0;
		for(String key : hashmap.keySet()) {
			currentValue = currentValue + hashmap.get(key) * hashmap.get(key);
		}
		// System.out.println("BS"+currentValue);
		value = Math.sqrt(currentValue);
		// System.out.println("E:"+value);
		return value;
	}

	public double getDotProduct(String file1, String file2) {
		Document d1 = findDocument(file1);
		Document d2 = findDocument(file2);

		HashMap<String, Integer> hashmap1 = d1.getHashMap();
		HashMap<String, Integer> hashmap2 = d2.getHashMap();

		int value = 0;
		int value1 = 0;
		int value2 = 0;
		for(String key1 : hashmap1.keySet()) {
			// System.out.print(key + ":");
			value1 = hashmap1.get(key1);
			// System.out.println(value);
			for(String key2 : hashmap2.keySet()) {
				if(key1.equals(key2)) {
					value2 = hashmap2.get(key2);
					value += value1 * value2;
				}
			}
		}
		// System.out.println((value));
		return value;
	}

	public double cosineSimilarity(String file1, String file2) {
		double num = getDotProduct(file1, file2);
		double denom = getEuclideanNorm(file1) * getEuclideanNorm(file2);
		double cosine = num/denom;
		// System.out.println(cosine);
		return cosine;
	}

	public void documentSimilarity() {
		if(documentArraySize == 0) {
			System.out.println("empty directory");
		}
		for(int i = 0; i < documentArraySize; i++) {
			// Document d = documents[i];
			for(int j = 0; j < documentArraySize; j++) {
				double res = cosineSimilarity(documents[i].getfilename(),documents[j].getfilename());
				System.out.print(Math.round(res*100)+"\t");
			}
			System.out.println();
		}
	}

}